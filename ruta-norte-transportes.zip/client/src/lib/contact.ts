const WHATSAPP_PHONE = "17025741780";

export const WHATSAPP_URL = `https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent("Hola, me gustaría consultar el transporte de una carga.")}`;
export const WHATSAPP_DISPLAY_NUMBER = "+1 (702) 574-1780";
