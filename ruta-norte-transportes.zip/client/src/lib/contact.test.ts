import { describe, expect, it } from "vitest";
import { WHATSAPP_URL } from "./contact";
import { buildDirectionsUrl, coverageRoutes } from "@/components/CoverageMap";

describe("contact links", () => {
  it("builds a direct WhatsApp URL with the configured business number", () => {
    expect(WHATSAPP_URL).toMatch(/^https:\/\/wa\.me\/17025741780\?text=/);
  });

  it("provides selectable route data from the Las Vegas starting point", () => {
    expect(coverageRoutes).toHaveLength(4);
    expect(coverageRoutes.every(route => route.origin === "Las Vegas, NV")).toBe(true);
  });

  it("builds a Google Maps directions URL for a selected route", () => {
    const url = buildDirectionsUrl("Las Vegas, NV", "Phoenix, AZ");
    expect(url).toContain("https://www.google.com/maps/dir/?api=1");
    expect(url).toContain("origin=Las%20Vegas%2C%20NV");
    expect(url).toContain("destination=Phoenix%2C%20AZ");
  });
});
