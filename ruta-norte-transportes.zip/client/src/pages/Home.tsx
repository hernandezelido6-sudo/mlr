/**
 * Ruta de Acero — Página de marketing editorial-industrial.
 * Prioriza evidencia fotográfica real, señalética de carretera y el naranja baliza para acciones.
 */
import { FormEvent, useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { CoverageMap } from "@/components/CoverageMap";
import { WHATSAPP_URL } from "@/lib/contact";
import { trpc } from "@/lib/trpc";
import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  Check,
  ChevronRight,
  Clock3,
  Compass,
  Menu,
  MessageCircle,
  MoveUpRight,
  Route,
  ShieldCheck,
  Truck,
  X,
} from "lucide-react";

const heroImage = "/manus-storage/ruta-norte-hero_a358cb20.jpg";
const routeDetail = "/manus-storage/ruta-norte-route-detail_0b90023a.jpg";
const workshopImage = "/manus-storage/ruta-norte-workshop_c485e67c.jpg";
const patternImage = "/manus-storage/ruta-norte-line-pattern_824faaa1.jpg";
const logoImage = "/manus-storage/ruta-norte-logo_9f5d51a5.png";
const trailerBlack = "/manus-storage/carga-remolque-negro_b7af34fc.jpg";
const trailerFifthWheel = "/manus-storage/carga-quinta-rueda_d220a323.jpg";

const services = [
  {
    number: "01",
    title: "Remolques de viaje",
    text: "Movimientos planificados para unidades de viaje, con coordinación clara desde la recogida hasta la entrega.",
    icon: Truck,
  },
  {
    number: "02",
    title: "Fifth wheels & campers",
    text: "Atención al tipo de enganche, dimensiones y condiciones de ruta que exige cada unidad recreativa.",
    icon: Compass,
  },
  {
    number: "03",
    title: "Cargas especiales",
    text: "Una evaluación previa del trayecto para organizar el transporte de equipos que requieren más criterio.",
    icon: Route,
  },
];

const steps = [
  ["01", "Escuchamos tu ruta", "Nos compartes el tipo de carga, origen, destino y ventana estimada."],
  ["02", "Trazamos el traslado", "Organizamos los detalles del movimiento antes de poner el equipo en marcha."],
  ["03", "Coordinamos la entrega", "Mantenemos una comunicación simple y directa hasta el punto de llegada."],
];

export default function Home() {
  const { isAuthenticated, loading } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const [sent, setSent] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const quoteMutation = trpc.quote.create.useMutation();

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (loading || quoteMutation.isPending) return;
    if (!isAuthenticated) {
      startLogin();
      return;
    }
    const form = event.currentTarget;
    const data = new FormData(form);
    const value = (name: string) => String(data.get(name) ?? "");
    setSent(false);
    setFormError(null);
    quoteMutation.mutate(
      {
        name: value("nombre"),
        phone: value("telefono"),
        email: value("correo"),
        cargo: value("carga") as "Remolque de viaje" | "Fifth wheel / camper" | "Carga especial" | "Otro",
        origin: value("origen"),
        destination: value("destino"),
        details: value("detalles"),
        website: value("website"),
      },
      {
        onSuccess: () => {
          form.reset();
          setSent(true);
        },
        onError: error => {
          setFormError(error.data?.code === "TOO_MANY_REQUESTS" ? "Hemos recibido varias solicitudes. Espera un momento antes de intentarlo nuevamente." : "No fue posible enviar la solicitud. Verifica los datos e inténtalo otra vez.");
        },
      }
    );
  };

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="site-shell">
      <header className="topbar">
        <a href="#inicio" className="brand" aria-label="Ruta Norte Transportes, inicio">
          <span className="brand-mark"><img src={logoImage} alt="" /></span>
          <span className="brand-copy">
            <strong>RUTA NORTE</strong>
            <small>TRANSPORTES</small>
          </span>
        </a>

        <nav className="desktop-nav" aria-label="Navegación principal">
          <a href="#servicios">Servicios</a>
          <a href="#proceso">Proceso</a>
          <a href="#cargas">Cargas</a>
          <a href="#rutas">Rutas</a>
          <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer" className="nav-whatsapp">WhatsApp <MessageCircle size={14} /></a>
          <a href="#cotizar" className="nav-cta">Cotizar traslado <ArrowUpRight size={15} /></a>
        </nav>

        <button
          className="menu-toggle"
          type="button"
          onClick={() => setMenuOpen((open) => !open)}
          aria-expanded={menuOpen}
          aria-label={menuOpen ? "Cerrar menú" : "Abrir menú"}
        >
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>

        {menuOpen && (
          <nav className="mobile-menu" aria-label="Navegación móvil">
            <a href="#servicios" onClick={closeMenu}>Servicios <ChevronRight size={16} /></a>
            <a href="#proceso" onClick={closeMenu}>Proceso <ChevronRight size={16} /></a>
            <a href="#cargas" onClick={closeMenu}>Cargas <ChevronRight size={16} /></a>
            <a href="#rutas" onClick={closeMenu}>Rutas <ChevronRight size={16} /></a>
            <a href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer" onClick={closeMenu}>WhatsApp <MessageCircle size={16} /></a>
            <a href="#cotizar" onClick={closeMenu} className="mobile-menu-cta">Cotizar traslado <ArrowUpRight size={16} /></a>
          </nav>
        )}
      </header>

      <main>
        <section id="inicio" className="hero-section">
          <img className="hero-image" src={heroImage} alt="Carretera abierta al anochecer" />
          <div className="hero-wash" />
          <div className="hero-grain" />
          <div className="hero-layout">
            <div className="hero-kicker"><span /> MOVIMIENTO ESPECIALIZADO</div>
            <h1>LA RUTA PARA<br /><em>LO QUE IMPORTA.</em></h1>
            <p className="hero-copy">Transportamos remolques, campers y cargas especiales con planificación de ruta y una coordinación que se entiende de principio a fin.</p>
            <div className="hero-actions">
              <a className="button button-orange" href="#cotizar">Solicitar cotización <ArrowRight size={18} /></a>
              <a className="button button-whatsapp" href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer">Hablar por WhatsApp <MessageCircle size={17} /></a>
              <a className="text-link light-link" href="#cargas">Ver nuestros movimientos <ArrowDownRight size={18} /></a>
            </div>
          </div>
          <div className="hero-route-tag"><span>RUTA</span><b>01</b><i /></div>
          <div className="hero-edge-note"><span>TRANSPORTE</span><span>CON PROPÓSITO</span></div>
        </section>

        <section className="intro-strip" aria-label="Presentación">
          <span className="section-index">[ 001 ]</span>
          <p>Una carga especial no se improvisa. Se lee, se prepara y se acompaña <strong>kilómetro a kilómetro.</strong></p>
          <a href="#proceso" className="circle-link" aria-label="Conocer el proceso"><ArrowDownRight size={22} /></a>
        </section>

        <section id="servicios" className="services-section">
          <div className="section-heading services-heading">
            <div>
              <span className="eyebrow">CAPACIDADES</span>
              <h2>HECHO PARA<br />MOVER <em>MEJOR.</em></h2>
            </div>
            <p>No se trata solo de remolcar. Es saber qué estás moviendo, cómo debe viajar y qué necesita el trayecto.</p>
          </div>

          <div className="service-grid">
            {services.map(({ number, title, text, icon: Icon }) => (
              <article className="service-card" key={number}>
                <div className="card-top"><span>{number}</span><Icon size={23} strokeWidth={1.6} /></div>
                <h3>{title}</h3>
                <p>{text}</p>
                <a href="#cotizar" aria-label={`Cotizar ${title}`}>Explorar servicio <ArrowRight size={17} /></a>
              </article>
            ))}
          </div>
        </section>

        <section id="proceso" className="process-section">
          <img className="route-detail" src={routeDetail} alt="Detalle de una línea de seguridad sobre asfalto" />
          <div className="process-overlay" />
          <div className="process-header">
            <span className="eyebrow light-eyebrow">UNA RUTA CLARA</span>
            <h2>MENOS INCERTIDUMBRE.<br /><em>MÁS CONTROL.</em></h2>
          </div>
          <div className="process-steps">
            {steps.map(([number, title, text]) => (
              <article key={number} className="process-step">
                <span>{number}</span>
                <div>
                  <h3>{title}</h3>
                  <p>{text}</p>
                </div>
              </article>
            ))}
          </div>
          <div className="process-stamp"><ShieldCheck size={19} /><span>PLANIFICACIÓN<br />ANTES DE PARTIR</span></div>
        </section>

        <section id="cargas" className="proof-section">
          <div className="proof-intro">
            <span className="eyebrow">EN MOVIMIENTO</span>
            <h2>LA EVIDENCIA<br />VIAJA <em>CON NOSOTROS.</em></h2>
            <p>Estas imágenes muestran el tipo de unidades que podemos coordinar para su traslado. Cada viaje empieza por conocer los detalles de la carga.</p>
            <a href="#cotizar" className="text-link dark-link">Tengo una carga similar <ArrowRight size={18} /></a>
          </div>

          <div className="proof-gallery">
            <figure className="gallery-photo gallery-photo-main">
              <img src={trailerBlack} alt="Remolque recreativo grande preparado para transporte" />
              <figcaption><span>UNIDAD 01</span><b>Remolque de viaje</b></figcaption>
            </figure>
            <figure className="gallery-photo gallery-photo-side">
              <img src={trailerFifthWheel} alt="Camper de quinta rueda conectado a una camioneta" />
              <figcaption><span>UNIDAD 02</span><b>Fifth wheel</b></figcaption>
            </figure>
            <div className="gallery-meter"><span>CARGAS</span><b>02</b><i /></div>
          </div>
        </section>

        <section className="care-section">
          <div className="care-image-wrap"><img src={workshopImage} alt="Detalles de enganche y equipo de transporte" /></div>
          <div className="care-copy">
            <span className="eyebrow">DETALLES QUE SOSTIENEN EL VIAJE</span>
            <h2>EL CUIDADO<br />TAMBIÉN ES <em>RUTA.</em></h2>
            <ul>
              <li><Check size={18} /> Conversación previa sobre la unidad y el traslado.</li>
              <li><Check size={18} /> Coordinación de carga, entrega y puntos importantes.</li>
              <li><Check size={18} /> Un equipo que entiende el valor de tu inversión.</li>
            </ul>
          </div>
        </section>

        <section id="rutas" className="coverage-section">
          <div className="coverage-copy">
            <span className="eyebrow">COBERTURA A MEDIDA</span>
            <h2>TU ORIGEN.<br />TU <em>DESTINO.</em></h2>
            <p>Utiliza el mapa para visualizar una ruta de conducción orientativa. La disponibilidad y los detalles del traslado se confirman de forma personalizada antes de partir.</p>
            <a className="button button-orange coverage-whatsapp" href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer">Consultar cobertura <MessageCircle size={18} /></a>
          </div>
          <CoverageMap />
        </section>

        <section id="cotizar" className="quote-section">
          <img className="quote-pattern" src={patternImage} alt="Patrón abstracto de rutas" />
          <div className="quote-content">
            <div className="quote-lead">
              <span className="eyebrow light-eyebrow">INICIEMOS EL RECORRIDO</span>
              <h2>CUÉNTANOS<br />EL <em>TRAYECTO.</em></h2>
              <p>Completa los detalles esenciales y tendremos la información necesaria para preparar tu cotización.</p>
              <div className="quote-side-note"><Clock3 size={18} /><span>Respuesta basada en la información real de tu carga y su ruta.</span></div>
            </div>

            <form className="quote-form" onSubmit={handleSubmit}>
              <div className="bot-trap" aria-hidden="true"><label>Website<input name="website" tabIndex={-1} autoComplete="off" /></label></div>
              <div className="field-row">
                <label>Nombre<input required name="nombre" placeholder="Tu nombre" /></label>
                <label>Teléfono<input required name="telefono" type="tel" placeholder="Tu número" /></label>
              </div>
              <div className="field-row">
                <label>Correo<input required name="correo" type="email" placeholder="tu@email.com" /></label>
                <label>Tipo de carga<select required name="carga" defaultValue=""><option value="" disabled>Selecciona una opción</option><option>Remolque de viaje</option><option>Fifth wheel / camper</option><option>Carga especial</option><option>Otro</option></select></label>
              </div>
              <div className="field-row">
                <label>Origen<input required name="origen" placeholder="Ciudad o punto de recogida" /></label>
                <label>Destino<input required name="destino" placeholder="Ciudad o punto de entrega" /></label>
              </div>
              <label>Detalles de la unidad<textarea name="detalles" placeholder="Medidas aproximadas, fecha preferida o cualquier dato importante." rows={3} /></label>
              {!isAuthenticated && !loading && <p className="form-security-note"><ShieldCheck size={15} /> Para proteger tus datos y evitar solicitudes automatizadas, inicia sesión antes de enviar.</p>}
              <button className="button button-orange form-button" type="submit" disabled={loading || quoteMutation.isPending}>{!isAuthenticated ? "Iniciar sesión para enviar" : quoteMutation.isPending ? "Enviando solicitud..." : "Enviar solicitud"} <MoveUpRight size={18} /></button>
              {sent && <p className="form-success" role="status">Solicitud enviada de forma segura. Podrás revisarla desde tu sesión.</p>}
              {formError && <p className="form-error" role="alert">{formError}</p>}
            </form>
          </div>
        </section>
      </main>

      <a className="floating-whatsapp" href={WHATSAPP_URL} target="_blank" rel="noopener noreferrer" aria-label="Hablar con Ruta Norte Transportes por WhatsApp"><MessageCircle size={20} /><span>WhatsApp</span></a>

      <footer className="site-footer">
        <div className="footer-top">
          <a href="#inicio" className="brand footer-brand">
            <span className="brand-mark"><img src={logoImage} alt="" /></span>
            <span className="brand-copy"><strong>RUTA NORTE</strong><small>TRANSPORTES</small></span>
          </a>
          <p>Transporte especializado para lo que no puede viajar de cualquier manera.</p>
          <a className="footer-cta" href="#cotizar">Solicitar cotización <ArrowUpRight size={17} /></a>
        </div>
        <div className="footer-bottom"><span>© {new Date().getFullYear()} Ruta Norte Transportes</span><span>Diseñado para mover con propósito.</span></div>
      </footer>
    </div>
  );
}
